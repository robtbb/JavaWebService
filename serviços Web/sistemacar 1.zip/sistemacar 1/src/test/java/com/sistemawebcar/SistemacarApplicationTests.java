package com.sistemawebcar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemacarApplicationTests {

	@Test
	void contextLoads() {
	}

}
