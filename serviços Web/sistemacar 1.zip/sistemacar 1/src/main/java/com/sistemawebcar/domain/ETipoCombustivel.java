package com.sistemawebcar.domain;

public enum ETipoCombustivel {

    GASOLINA, ETANOL, FLEX, DIESEL, GNV, OUTRO;

}
