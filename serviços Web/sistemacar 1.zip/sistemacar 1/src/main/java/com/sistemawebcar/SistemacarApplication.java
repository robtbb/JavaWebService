package com.sistemawebcar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemacarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemacarApplication.class, args);
	}

}
