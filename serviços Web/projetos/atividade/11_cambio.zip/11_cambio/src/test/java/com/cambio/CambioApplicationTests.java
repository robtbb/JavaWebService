package com.cambio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CambioApplicationTests {

	@Test
	void contextLoads() {
	}

}
