package com.cambio;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MoedaService {

    private final Map<String, Double> cotacoesCompra = new HashMap<>();
    private final Map<String, Double> cotacoesVenda = new HashMap<>();

    public MoedaService() {
        // Initialize buy quotes
        cotacoesCompra.put("DC", 5.6061);
        cotacoesCompra.put("DP", 5.69);
        cotacoesCompra.put("DX", 5.6058);
        cotacoesCompra.put("DT", 5.5430);
        cotacoesCompra.put("EU", 6.5630);
        cotacoesCompra.put("OU", 346.70);

        // Initialize sell quotes
        cotacoesVenda.put("DC", 5.6066);
        cotacoesVenda.put("DP", 5.79);
        cotacoesVenda.put("DX", 5.6064);
        cotacoesVenda.put("DT", 5.7530);
        cotacoesVenda.put("EU", 6.8070);
        cotacoesVenda.put("OU", 346.70 * 1.0188); // Including a 1.88% increase
    }

    public double converter(double quantia, String tipoMoeda, String tipoOperacao) {
        if ("compra".equalsIgnoreCase(tipoOperacao)) {
            return quantia / cotacoesCompra.get(tipoMoeda);
        } else {
            return quantia * cotacoesVenda.get(tipoMoeda);
        }
    }

    public List<MoedaDTO> converterParaTodasMoedas(double quantia, String tipoOperacao) {
        List<MoedaDTO> resultados = new ArrayList<>();

        for (String moeda : cotacoesCompra.keySet()) {
            double valorConvertido = converter(quantia, moeda, tipoOperacao);
            resultados.add(new MoedaDTO(moeda, "compra".equalsIgnoreCase(tipoOperacao) ? valorConvertido : quantia,
                    "venda".equalsIgnoreCase(tipoOperacao) ? valorConvertido : quantia));
        }

        return resultados;
    }

    public List<MoedaDTO> getCotacoes() {
        List<MoedaDTO> cotacoes = new ArrayList<>();
        for (String moeda : cotacoesCompra.keySet()) {
            MoedaDTO cotacao = new MoedaDTO(moeda, cotacoesCompra.get(moeda), cotacoesVenda.get(moeda));
            cotacoes.add(cotacao);
        }
        return cotacoes;
    }
}
