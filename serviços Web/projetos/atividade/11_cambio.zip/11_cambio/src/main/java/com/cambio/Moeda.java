package com.cambio;

import java.util.Map;

public class Moeda {
    private double valor;
    private String operacao;
    private Map<String, Double> resultados;

    public Moeda(double valor, String operacao, Map<String, Double> resultados) {
        this.valor = valor;
        this.operacao = operacao;
        this.resultados = resultados;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getOperacao() {
        return operacao;
    }

    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }

    public Map<String, Double> getResultados() {
        return resultados;
    }

    public void setResultados(Map<String, Double> resultados) {
        this.resultados = resultados;
    }
}
