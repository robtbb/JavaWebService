package br.edu.ifsc.fln.primeiroexemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroexemploApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
