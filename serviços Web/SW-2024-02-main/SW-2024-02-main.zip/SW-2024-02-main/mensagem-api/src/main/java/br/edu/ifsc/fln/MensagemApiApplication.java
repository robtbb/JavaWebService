package br.edu.ifsc.fln;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MensagemApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MensagemApiApplication.class, args);
	}

}
