Link de acesso ao tutorial para instalação da extensão: https://ia-tec-development.medium.com/lombok-como-instalar-na-spring-tool-suite-4-ide-48defb1d0eb9

Fiz um novo projeto para teste e disponibilizei no git: https://github.com/mpisching/AulasServicosWeb/tree/master/Aula16-10-2024/cursos-lombok-api