package br.edu.ifsc.fln.domain;

public enum ESituacao {
	ATIVO, INATIVO, BLOQUEADO;
}
