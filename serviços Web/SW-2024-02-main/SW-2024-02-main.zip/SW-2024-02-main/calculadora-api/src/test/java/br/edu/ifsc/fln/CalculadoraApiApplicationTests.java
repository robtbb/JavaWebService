package br.edu.ifsc.fln;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
