package br.edu.ifsc.fln;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculadoraApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculadoraApiApplication.class, args);
	}

}
