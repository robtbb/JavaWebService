package br.edu.ifsc.fln.domain;

public class Calculadora {
	public static int somar(int a, int b) {
		return a + b;
	}
	
	public static Double somar(Double a, Double b) {
		return a + b;
	}
	
	public static int subtrair(int a, int b) {
		return a - b;
	}
}
