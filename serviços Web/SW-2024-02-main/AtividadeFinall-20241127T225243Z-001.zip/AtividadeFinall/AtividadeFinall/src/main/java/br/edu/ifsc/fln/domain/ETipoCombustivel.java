package br.edu.ifsc.fln.domain;

public enum ETipoCombustivel {
	
	  GASOLINA, ETANOL, FLEX, DIESEL, GNV, OUTRO;
}
